A small WebExtension that auto closes the zoom tab (https://zoom.us/) when you launch a meeting, because it doesn't do that itself for some reason.

originally authored by https://github.com/andymckay
